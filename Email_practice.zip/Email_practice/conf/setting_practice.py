#!/usr/bin/env python 
# -*- coding:utf-8 -*-
# @Time   : 2019/8/27 0027 20:29 
# @Autohor: Sam
# @File   : setting_practice.py


import os

BASE_DIR = os.path.dirname(os.path.dirname(__file__))

BASE_DB = os.path.join(BASE_DIR, 'db')
BASE_LOG = os.path.join(BASE_DIR, 'log' )

