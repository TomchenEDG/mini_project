#!/usr/bin/env python 
# -*- coding:utf-8 -*-
# @Time   : 2019/8/27 0027 20:27 
# @Autohor: Sam
# @File   : db_handler_practice.py

import os
import json
from conf import setting_practice


def select(user_dic):
    user_path = os.path.join(setting_practice.BASE_DB, '%s.json'%user_dic['name'])
    if os.path.exists(user_path):
        with open(user_path, 'w', encoding='utf-8') as f:
            user_dic = json.load(f)
            return user_dic
    else:
        return None


def save(user_dict):
    user_path = os.path.join(setting_practice.BASE_DB, '%s.json'%user_dict['name'])
    with open(user_path, 'w',encoding='utf-8') as f:
        json.dump(user_dict, f, ensure_ascii=False)
        f.flush()