#!/usr/bin/env python 
# -*- coding:utf-8 -*-
# @Time   : 2019/8/27 0027 20:11 
# @Autohor: Sam
# @File   : src_pracitce.py

from interface import user_practice

user_data = {
    'name': None
}

def login():
    print('登陆')
    if user_data['name']:
        print('你已经登录了')
        return

    count = 0
    while True:
        name = input('name:>>')
        if name == 'q':
            return
        password = input('password:>>')
        flag, msg = user_practice.login_interface(name, password)
        if flag:
            user_data['name'] = name
            print(msg)
            break
        else:
            print(msg)
            count += 1
            if count == 3:
                user_practice.lock_user_interface(name)
                print('尝试过多，已经锁定')
                break

func_dict1 = {
    '1':login,
}

def run():
    while True:
        print("""
        1.登录
        """)

        choice = input("请选择：")
        if choice in func_dict1:
            func_dict1[choice]()
