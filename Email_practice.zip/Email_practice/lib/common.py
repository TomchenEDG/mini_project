#!/usr/bin/env python 
# -*- coding:utf-8 -*-
# @Time   : 2019/8/26 0026 18:28 
# @Autohor: Sam
# @File   : common.py