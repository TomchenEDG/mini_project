#!/usr/bin/env python 
# -*- coding:utf-8 -*-
# @Time   : 2019/8/27 0027 20:25 
# @Autohor: Sam
# @File   : user_practice.py

from db import db_handler_practice

def login_interface(name, password):
    user_dict = db_handler_practice.select(name)
    if user_dict:
        if password == user_dict['password'] and not user_dict['locked']:
            return True, '登录成功'
        else:
            return False, '用户密码错误 或者 已锁定'
    else:
        return False, '用户不存在'


def lock_user_interface(name):
    user_dict = db_handler_practice.select(name)
    if user_dict:
        user_dict['locked'] = True
        db_handler_practice.save(user_dict)